public class Fournisseur {
    private String name;
    private IProduit produit;

    public Fournisseur(String name){
        setName(name);
    }

    public Fournisseur(String name, IProduit produit) {
        this(name);
        setProduit(produit);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public IProduit getProduit() {
        return produit;
    }

    public void setProduit(IProduit produit) {
        this.produit = produit;
    }


    @Override
    public String toString() {
        return "Fournisseur{" +
                "name='" + name + '\'' +
                ", produit=" + produit.getName() +
                '}';
    }
}
