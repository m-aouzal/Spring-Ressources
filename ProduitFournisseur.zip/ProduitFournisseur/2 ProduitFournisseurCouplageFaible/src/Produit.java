public class Produit implements IProduit {
    private String name;
    private Fournisseur fournisseur;

    public Produit(String name, Fournisseur fournisseur) {
        setName(name);
        setFournisseur(fournisseur);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Fournisseur getFournisseur() {
        return fournisseur;
    }

    @Override
    public void setFournisseur(Fournisseur fournisseur) {
        this.fournisseur = fournisseur;
        fournisseur.setProduit(this);
    }

    @Override
    public int getPrix(){
        return 1000;
    }


    @Override
    public String toString() {
        return "Produit{" +
                "name='" + name + '\'' +
                ", fournisseur=" + fournisseur.getName() +
                ", prix=" + getPrix() +
                '}';
    }
}
