public interface IProduit {
    String getName();

    void setName(String name);

    Fournisseur getFournisseur();

    void setFournisseur(Fournisseur fournisseur);

    int getPrix();
}
