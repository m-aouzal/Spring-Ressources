public class Produit3 implements IProduit{
    private String name;
    private IFournisseur fournisseur;

    //JavaBean
    public Produit3() {
    }

    public Produit3(String name, IFournisseur fournisseur) {
        setName(name);
        setFournisseur(fournisseur);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public IFournisseur getFournisseur() {
        return fournisseur;
    }

    public void setFournisseur(IFournisseur fournisseur) {
        this.fournisseur = fournisseur;
        //le fournisseur accepte les objets de la classe Produit2
        //dependance faible !!!
        fournisseur.setProduit(this);
    }

    public int getPrix(){
        return 1000*getName().length()*2;
    }


    @Override
    public String toString() {
        return "Produit3{" +
                "name='" + name + '\'' +
                ", fournisseur=" + fournisseur.getName() +
                ", prix=" + getPrix() +
                '}';
    }
}
