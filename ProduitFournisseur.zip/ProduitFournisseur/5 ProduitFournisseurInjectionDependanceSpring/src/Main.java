import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //inverse of controle  IOC
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

        // injection dependance
        IFournisseur hp = (IFournisseur) context.getBean("hp");
        IProduit x360 = (IProduit) context.getBean("x360");
        System.out.println("hp = " + hp);
        System.out.println("x360 = " + x360);

        System.out.println();
        System.out.println("Utilisation de la version amelioree de Produit");
        System.out.println();

        IProduit x3602 = (IProduit) context.getBean("x3602");
        System.out.println("x3602 = " + x3602);
        System.out.println("hp = " + hp);
    }
}