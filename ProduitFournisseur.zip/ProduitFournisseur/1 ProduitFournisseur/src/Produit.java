public class Produit {
    private String name;
    private Fournisseur fournisseur;

    public Produit(String name, Fournisseur fournisseur) {
        setName(name);
        setFournisseur(fournisseur);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Fournisseur getFournisseur() {
        return fournisseur;
    }

    //Code Incomplet
    public void setFournisseur(Fournisseur fournisseur) {
        this.fournisseur = fournisseur;
        fournisseur.setProduit(this);
    }

    public int getPrix(){
        return 1000;
    }


    @Override
    public String toString() {
        return "Produit{" +
                "name='" + name + '\'' +
                ", fournisseur=" + fournisseur.getName() +
                ", prix=" + getPrix() +
                '}';
    }
}
