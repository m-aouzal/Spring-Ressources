public class Fournisseur {
    private String name;
    private Produit2 produit;

    public Fournisseur(String name){
        setName(name);
    }

    public Fournisseur(String name, Produit2 produit) {
        this(name);
        setProduit(produit);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Produit2 getProduit() {
        return produit;
    }

    //Code Imcomplet
    public void setProduit(Produit2 produit) {
        this.produit = produit;
    }


    @Override
    public String toString() {
        return "Fournisseur{" +
                "name='" + name + '\'' +
                ", produit=" + produit.getName() +
                '}';
    }
}
