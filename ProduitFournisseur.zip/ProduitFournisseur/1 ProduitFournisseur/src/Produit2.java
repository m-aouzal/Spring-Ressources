public class Produit2 {
    private String name;
    private Fournisseur fournisseur;

    public Produit2(String name, Fournisseur fournisseur) {
        setName(name);
        setFournisseur(fournisseur);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Fournisseur getFournisseur() {
        return fournisseur;
    }

    public void setFournisseur(Fournisseur fournisseur) {
        this.fournisseur = fournisseur;
        //le fournisseur n'accepte que les objets de la classe Produit
        //dependance forte !!!
//        fournisseur.setProduit(this);
    }

    public int getPrix(){
        return 1000*getName().length();
    }


    @Override
    public String toString() {
        return "Produit2{" +
                "name='" + name + '\'' +
                ", fournisseur=" + fournisseur.getName() +
                ", prix=" + getPrix() +
                '}';
    }
}
