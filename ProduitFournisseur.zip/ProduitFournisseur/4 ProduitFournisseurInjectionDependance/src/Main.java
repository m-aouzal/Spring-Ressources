import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String classProduitName = "";
        String classProduit2Name = "";
        String classFournisseurName = "";
        String methodeSetFournisseurName = "";
        String methodeSetNameName = "";
        IProduit x360 = null;
        IProduit x3602 = null;
        IFournisseur hp = null;
        try {
//            Scanner scanner = new Scanner(System.in);
            Scanner scanner = new Scanner(new FileReader("Config.txt"));

            classProduitName = scanner.next();
            classProduit2Name = scanner.next();
            classFournisseurName = scanner.next();
            methodeSetNameName = scanner.next();
            methodeSetFournisseurName = scanner.next();

            // Chargement dynamique des classes
            Class produitClass = Class.forName(classProduitName);
            // Creation d'instance
            // IProduit x360 = new Produit()
            x360 = (IProduit) produitClass.newInstance();
            // Invocation d'une methode d'objet
            Method methodeSetName2 = produitClass.getMethod(methodeSetNameName, new Class[]{String.class});
            // x360.setName("Elitebook x360");
            methodeSetName2.invoke(x360, "Elitebook x360");

            Class FournisseurClass = Class.forName(classFournisseurName);
            // IFournisseur hp = new Fournisseur();
            hp = (IFournisseur) FournisseurClass.newInstance();
            Method methodeSetName = FournisseurClass.getMethod(methodeSetNameName, new Class[]{String.class});
            // hp.setName("hp")
            methodeSetName.invoke(hp, "hp");
            Method methodeSetFournisseur = produitClass.getMethod(methodeSetFournisseurName, new Class[]{IFournisseur.class});
            // Injection de dependance par la methode setter
            // x360.setFournisseur(hp)
            methodeSetFournisseur.invoke(x360, hp);

            System.out.println("hp = " + hp);
            System.out.println("x360 = " + x360);

            System.out.println();
            System.out.println("Utilisation de la version amelioree de Produit");
            System.out.println();


            //Produit2 x360
            produitClass = Class.forName(classProduit2Name);
            x3602 = (IProduit) produitClass.newInstance();
            methodeSetName2 = produitClass.getMethod(methodeSetNameName, new Class[]{String.class});
            methodeSetName2.invoke(x3602, "Elitebook x3602");
            methodeSetFournisseur = produitClass.getMethod(methodeSetFournisseurName, new Class[]{IFournisseur.class});
            methodeSetFournisseur.invoke(x3602, hp);

            System.out.println("x3602 = " + x3602);
            System.out.println("hp = " + hp);

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InstantiationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}