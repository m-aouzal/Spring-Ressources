import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        IFournisseur hp = new Fournisseur("HP"); //attention encore une dependence vers la Classe Founisseur
        IProduit x360 = new Produit("Elitebook x360", hp); //attention encore une dependence vers la Classe Produit

        System.out.println("hp = " + hp);
        System.out.println("x360 = " + x360);

        System.out.println();
        System.out.println("Utilisation de la version amelioree de Produit");
        System.out.println();

        //utilisation de Produit2 (version ameliore de la classe Produit)
        IProduit x3602 = new Produit2("Elitebook x3602", hp);//attention encore une dependence vers la Classe Produit2
        System.out.println("x3602 = " + x3602);
        System.out.println("hp = " + hp);
    }
}