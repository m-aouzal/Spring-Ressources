public class Produit implements IProduit {
    private String name;
    private IFournisseur fournisseur;

    public Produit(String name, IFournisseur fournisseur) {
        setName(name);
        setFournisseur(fournisseur);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public IFournisseur getFournisseur() {
        return fournisseur;
    }

    @Override
    public void setFournisseur(IFournisseur fournisseur) {
        this.fournisseur = fournisseur;
        fournisseur.setProduit(this);
    }

    @Override
    public int getPrix(){
        return 1000;
    }


    @Override
    public String toString() {
        return "Produit{" +
                "name='" + name + '\'' +
                ", fournisseur=" + fournisseur.getName() +
                ", prix=" + getPrix() +
                '}';
    }
}
