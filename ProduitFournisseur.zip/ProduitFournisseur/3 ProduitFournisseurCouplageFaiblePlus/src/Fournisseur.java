public class Fournisseur implements IFournisseur {
    private String name;
    private IProduit produit;

    public Fournisseur(String name){
        setName(name);
    }

    public Fournisseur(String name, IProduit produit) {
        this(name);
        setProduit(produit);
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public IProduit getProduit() {
        return produit;
    }

    @Override
    public void setProduit(IProduit produit) {
        this.produit = produit;
    }


    @Override
    public String toString() {
        return "Fournisseur{" +
                "name='" + name + '\'' +
                ", produit=" + produit.getName() +
                '}';
    }
}
