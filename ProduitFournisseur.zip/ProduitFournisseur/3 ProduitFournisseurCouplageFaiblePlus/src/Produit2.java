public class Produit2 implements IProduit{
    private String name;
    private IFournisseur fournisseur;

    public Produit2(String name, IFournisseur fournisseur) {
        setName(name);
        setFournisseur(fournisseur);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public IFournisseur getFournisseur() {
        return fournisseur;
    }

    public void setFournisseur(IFournisseur fournisseur) {
        this.fournisseur = fournisseur;
        //le fournisseur accepte les objets de la classe Produit2
        //dependance faible !!!
        fournisseur.setProduit(this);
    }

    public int getPrix(){
        return 1000*getName().length();
    }


    @Override
    public String toString() {
        return "Produit2{" +
                "name='" + name + '\'' +
                ", fournisseur=" + fournisseur.getName() +
                ", prix=" + getPrix() +
                '}';
    }
}
