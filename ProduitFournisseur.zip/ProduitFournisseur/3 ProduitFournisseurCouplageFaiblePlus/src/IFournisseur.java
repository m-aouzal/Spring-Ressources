public interface IFournisseur {
    void setName(String name);

    String getName();

    IProduit getProduit();

    void setProduit(IProduit produit);
}
