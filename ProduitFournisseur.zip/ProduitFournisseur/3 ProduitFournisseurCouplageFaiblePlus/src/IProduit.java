public interface IProduit {
    String getName();

    void setName(String name);

    IFournisseur getFournisseur();

    void setFournisseur(IFournisseur fournisseur);

    int getPrix();
}
