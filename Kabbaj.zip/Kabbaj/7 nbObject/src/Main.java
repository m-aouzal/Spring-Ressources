import ma.emi.aspect.Personne;

public class Main {
    public static void main(String[] args) {
        System.out.println("avant");
        for (int i = 0; i < 10; i++)
            new Personne();
        System.out.println("apres");
    }
}