import ma.emi.aspect.Compte;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
		traitement1();

        System.out.println();
        System.out.println("-----------------------------------------");
        System.out.println();

        try {
            Compte compte = new Compte();
            Scanner clavier = new Scanner(System.in);
            System.out.print("Code :");
            int code = clavier.nextInt();
            compte.setCode(code);
            while (true) {
                System.out.print("Montant a verser :");
                double mt1 = clavier.nextDouble();
                compte.verser(mt1);

                System.out.println(compte.toString());
                System.out.print("Montant a Retirer :");
                double mt2 = clavier.nextDouble();
                compte.retirer(mt2);
                System.out.println(compte.toString());
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }

    public static void traitement1() {
        Compte cp1 = new Compte();
        Compte cp2 = new Compte();
//		Compte cp3 = new Compte();
//		Compte cp4 = new Compte();
        cp1.setCode(1);
        cp1.verser(800);
//		cp1.retirer(9000);
        cp2.setCode(2);
//		cp1.virement(cp2, 9000);
        System.out.println(cp1.toString());
        System.out.println(cp2.toString());
    }

 }