import java.util.ArrayList;
import java.util.List;

public class Image {
    private String name;
    private List<Rectangle> rectangles = new ArrayList<>();
    private List<Ligne> lignes = new ArrayList<>();
    private List<Image> images = new ArrayList<>();

//    private List<Cercle> cercles= new ArrayList<>();

    public Image(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int sizeRegtangles() {
        return rectangles.size();
    }

    public boolean containsRegtangles(Object o) {
        return rectangles.contains(o);
    }

    public boolean addRegtangles(Rectangle rectangle) {
        return rectangles.add(rectangle);
    }

    public boolean removeRegtangles(Object o) {
        return rectangles.remove(o);
    }

    public Rectangle getRegtangles(int index) {
        return rectangles.get(index);
    }

    public int sizeLignes() {
        return lignes.size();
    }

    public boolean containsLignes(Object o) {
        return lignes.contains(o);
    }

    public boolean addLignes(Ligne ligne) {
        return lignes.add(ligne);
    }

    public boolean removeLignes(Object o) {
        return lignes.remove(o);
    }

    public Ligne getLignes(int index) {
        return lignes.get(index);
    }


    public int sizeImages() {
        return images.size();
    }

    public boolean containsImages(Object o) {
        return images.contains(o);
    }

    public boolean addImages(Image image) {
        return images.add(image);
    }

    public boolean removeImages(Object o) {
        return images.remove(o);
    }

    public Image getImages(int index) {
        return images.get(index);
    }


/*
    public int sizeCercles() {
        return cercles.size();
    }

    public boolean containsCercles(Object o) {
        return cercles.contains(o);
    }

    public boolean addCercles(Cercle cercle) {
        return cercles.add(cercle);
    }

    public boolean removeCercles(Object o) {
        return cercles.remove(o);
    }

    public Cercle getCercles(int index) {
        return cercles.get(index);
    }
*/


    @Override
    public String toString() {
        return "Image{" +
                "name='" + name + '\'' +
                ", rectangles=" + rectangles +
                ", lignes=" + lignes +
                ", images=" + images +
//                ", cercles=" + cercles +
                '}';
    }
}
