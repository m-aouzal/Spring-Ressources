public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Graphique g = new Graphique("Image 1");
        Image im = new Image("Image 2");
        Image im1 = new Image("Image 3");
        Image im2 = new Image("Image 4");
        g.addImages(im);
        im.addImages(im1);
        im1.addImages(im2);
        Rectangle r1 = new Rectangle("Rectangle 1");
        Rectangle r2 = new Rectangle("Rectangle 2");
        Rectangle r3 = new Rectangle("Rectangle 3");
        Triangle t1 = new Triangle("Triangle 1");
        g.addRegtangles(r1);
        im.addRegtangles(r2);
        im1.addRegtangles(r3);
        Ligne l1 = new Ligne("Ligne 1");
        Ligne l2 = new Ligne("Ligne 2");
        Ligne l3 = new Ligne("Ligne 3");
        g.addLignes(l1);
        im1.addLignes(l2);
        im2.addLignes(l3);
/*
        Cercle c1 = new Cercle("Crecle 1");
        Cercle c2 = new Cercle("Crecle 2");
        Cercle c3 = new Cercle("Crecle 3");
        g.addCercles(c1);
        im.addCercles(c2);
        im1.addCercles(c3);
*/
        System.out.println(g);
    }
}