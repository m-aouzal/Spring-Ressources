public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Image g = new Image("Image 1");
        Image im = new Image("Image 2");
        Image im1 = new Image("Image 3");
        Image im2 = new Image("Image 4");
        g.add(im);
        im.add(im1);
        im1.add(im2);
        Ligne l1 = new Ligne("Ligne 1");
        Ligne l2 = new Ligne("Ligne 2");
        Ligne l3 = new Ligne("Ligne 3");
        g.add(l1);
        im1.add(l2);
        im2.add(l3);
        Cercle c1 = new Cercle("Cercle 1");
        g.add(c1);

        Carre cr1 = new Carre("C1");
        Carre cr2 = new Carre("C2");

        g.add(cr1);
        im2.add(cr2);
        System.out.println(g);
        System.out.println("Taille globale : " + g.size());
    }
}