import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Image extends Graphique{

    List<Graphique> mesElements = new ArrayList<>();

    public Image(String name) {
        super(name);
    }

    public int size() {
        return mesElements.size();
    }

    public boolean contains(Object o) {
        return mesElements.contains(o);
    }

    public boolean add(Graphique graphique) {
        return mesElements.add(graphique);
    }

    public boolean remove(Object o) {
        return mesElements.remove(o);
    }

    public Graphique get(int index) {
        return mesElements.get(index);
    }


    @Override
    public String toString() {
        return "Image{" +
                "mesElements=" + mesElements +
                '}';
    }
}
