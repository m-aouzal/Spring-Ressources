public class Texte extends Graphique{
    public Texte(String name) {
        super(name);
    }


    @Override
    public String toString() {
        return "Texte{" +
                "name='" + super.getName() + '\'' +
                '}';
    }
}
