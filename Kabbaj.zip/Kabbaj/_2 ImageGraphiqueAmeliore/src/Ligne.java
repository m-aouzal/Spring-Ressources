public class Ligne extends Graphique{
    public Ligne(String name) {
        super(name);
    }


    @Override
    public String toString() {
        return "Ligne{" +
                "name='" + super.getName() + '\'' +
                '}';
    }
}
