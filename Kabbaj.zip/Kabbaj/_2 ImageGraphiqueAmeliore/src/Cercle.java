public class Cercle extends Graphique{
    public Cercle(String name) {
        super(name);
    }


    @Override
    public String toString() {
        return "Cercle{" +
                "name='" + super.getName() + '\'' +
                '}';
    }
}
