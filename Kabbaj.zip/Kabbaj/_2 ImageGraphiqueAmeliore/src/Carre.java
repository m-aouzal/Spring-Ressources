public class Carre extends Graphique{
    public Carre(String name) {
        super(name);
    }


    @Override
    public String toString() {
        return "Carre{" +
                "name='" + super.getName() + '\'' +
                '}';
    }
}
