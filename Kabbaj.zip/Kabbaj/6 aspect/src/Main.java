public class Main {
    public static void main(String[] args) {

        System.out.println("avant l'appel de la fonction");
        monTraitement();
        System.out.println("après l'appel de la fonction");

    }

    private static void monTraitement() {
        System.out.println("mon traitement metier");
    }

}