package ma.emi.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MonSecondAspect {

    @Pointcut("execution(private * *.monTraitement(..))")
    public void pc() {

    }

    @Before("execution(private * *.monTraitement(..))")
    public void avant() {
        System.out.println();
        System.out.println("*******************Debut du deuxieme aspect*******************");
        System.out.println("                      before");
        System.out.println();
    }

    @After("pc()")
    public void apres() {
        System.out.println();
        System.out.println("                    after");
        System.out.println("*******************Fin du deuxieme aspect*******************");
        System.out.println();

    }
}
