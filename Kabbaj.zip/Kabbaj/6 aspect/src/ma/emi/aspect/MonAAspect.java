package ma.emi.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MonAAspect {
    @Before("execution(private * *.monTraitement(..))")
    public void coucou() {
        System.out.println();
        System.out.println("*******************Debut du A aspect***************");
        System.out.println("                      before");
        System.out.println();
    }

    @After("execution(* *.monTraitement(..))")
    public void coucou2() {
        System.out.println();
        System.out.println("                    after");
        System.out.println("*******************Fin du A aspect****************'");
        System.out.println();

    }

}

